#include <stdio.h>

int main() {
    int n;
    printf("Digite um número inteiro não negativo: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Por favor, insira um número não negativo.\n");
    } else {
        int termo_atual = 0;
        int termo_anterior = 1;
        int resultado = 0;

        if (n == 0) {
            resultado = 0;
        } else if (n == 1) {
            resultado = 1;
        } else {
            for (int i = 2; i <= n; i++) {
                resultado = termo_atual + termo_anterior;
                termo_anterior = termo_atual;
                termo_atual = resultado;
            }
        }

        printf("O enésimo termo da sequência de Fibonacci é: %d\n", resultado);
    }

    return 0;
}
