#include <stdio.h>
#include <string.h>

struct Jogadora {
    char nome[100];
    int idade;
    char sexo;
    char voto;
};

int main() {
    const int MIN_ENTREVISTADOS = 50;
    const int MAX_ENTREVISTADOS = 300;
    const char opcoes_voto[] = "ABCDE";
    const int num_opcoes_voto = strlen(opcoes_voto);

    struct Jogadora jogadoras[] = {
        {"Marta Vieira", 35, 'F', 'A'},
        {"Cristiane Rozeira", 36, 'F', 'B'},
        {"Alex Morgan", 32, 'F', 'C'},
        {"Sam Kerr", 28, 'F', 'D'},
        {"Pernille Harder", 29, 'F', 'E'},
    };

    int total_entrevistados = 0;
    int votos[num_opcoes_voto] = {0};
    int idade_total = 0;
    int mulheres_participantes = 0;
    int maiores_de_idade = 0;
    int menores_de_idade = 0;
    int maiores_de_idade_votaram_marta = 0;

    printf("Bem-vindo à pesquisa para escolher a melhor jogadora da Copa do Mundo de Futebol Feminino!\n");
    printf("Por favor, responda às seguintes perguntas:\n");

    while (total_entrevistados < MAX_ENTREVISTADOS) {
        char nome[100];
        int idade;
        char sexo;
        char voto;

        printf("\nEntrevistado %d:\n", total_entrevistados + 1);

        printf("Nome da pessoa entrevistada: ");
        scanf(" %[^\n]s", nome);

        printf("Idade da pessoa entrevistada: ");
        scanf("%d", &idade);

        if (idade <= 12) {
            printf("A idade da pessoa entrevistada deve ser maior que 12 anos.\n");
            continue;
        }

        printf("Sexo da pessoa entrevistada (M/F): ");
        scanf(" %c", &sexo);

        if (sexo != 'M' && sexo != 'F') {
            printf("O sexo da pessoa entrevistada deve ser 'M' ou 'F'.\n");
            continue;
        }

        printf("Voto da pessoa entrevistada (A, B, C, D ou E): ");
        scanf(" %c", &voto);

        if (strchr(opcoes_voto, voto) == NULL) {
            printf("O voto da pessoa entrevistada deve ser 'A', 'B', 'C', 'D' ou 'E'.\n");
            continue;
        }

        for (int i = 0; i < num_opcoes_voto; i++) {
            if (voto == opcoes_voto[i]) {
                votos[i]++;
                break;
            }
        }

        idade_total += idade;
        if (sexo == 'F') {
            mulheres_participantes++;
        }
        if (idade >= 18) {
            maiores_de_idade++;
            if (strcmp(nome, "Marta Vieira") == 0) {
                maiores_de_idade_votaram_marta++;
            }
        } else {
            menores_de_idade++;
        }

        total_entrevistados++;

        if (total_entrevistados >= MIN_ENTREVISTADOS) {
            printf("\nVocê já entrevistou o número mínimo de pessoas (50).\n");
            printf("Deseja encerrar a pesquisa (S/N)? ");
            char resposta;
            scanf(" %c", &resposta);
            if (resposta == 'S' || resposta == 's') {
                break;
            }
        }
    }

    int max_votos = 0;
    for (int i = 0; i < num_opcoes_voto; i++) {
        if (votos[i] > max_votos) {
            max_votos = votos[i];
        }
    }

    printf("\nResultados da pesquisa:\n");
    printf("Quantidade de votos que cada jogadora recebeu:\n");
    for (int i = 0; i < num_opcoes_voto; i++) {
        printf("%s (%c): %d votos\n", jogadoras[i].nome, jogadoras[i].voto, votos[i]);
    }

    printf("\nJogadoras mais votadas:\n");
    for (int i = 0; i < num_opcoes_voto; i++) {
        if (votos[i] == max_votos) {
            printf("%s (%c) com %d votos\n", jogadoras[i].nome, jogadoras[i].voto, votos[i]);
        }
    }

    printf("\nNome, idade e sexo de todas as pessoas que participaram da pesquisa:\n");
    for (int i = 0; i < total_entrevistados; i++) {
        printf("%s, %d anos, %c\n", jogadoras[i].nome, jogadoras[i].idade, jogadoras[i].sexo);
    }

    printf("\nNome das pessoas maiores de idade que votaram na Marta Vieira:\n");
    if (maiores_de_idade_votaram_marta > 0) {
        for (int i = 0; i < total_entrevistados; i++) {
            if (jogadoras[i].idade >= 18 && strcmp(jogadoras[i].nome, "Marta Vieira") == 0) {
                printf("%s\n", jogadoras[i].nome);
            }
        }
    } else {
        printf("Nenhuma pessoa maior de idade votou na Marta Vieira.\n");
    }

    printf("\nQuantidade de mulheres que participaram da pesquisa: %d\n", mulheres_participantes);

    return 0;
}
