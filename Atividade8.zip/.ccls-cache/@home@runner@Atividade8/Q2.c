#include <stdio.h>

int main() {
    int numero_moradores = 50;
    int contador_elevador_a = 0;
    int contador_elevador_b = 0;
    int contador_elevador_c = 0;
    int contador_matutino = 0;
    int contador_vespertino = 0;
    int contador_noturno = 0;
    char elevador_mais_frequentado;
    char periodo_mais_usado;
    int maior_fluxo = 0;

    for (int i = 0; i < numero_moradores; i++) {
        char elevador;
        char periodo;

        printf("Morador %d:\n", i + 1);

        printf("Qual elevador você utiliza com mais frequência (A, B ou C)? ");
        scanf(" %c", &elevador);

        printf("Qual período você utiliza o elevador (M, V ou N)? ");
        scanf(" %c", &periodo);

        switch (elevador) {
            case 'A':
                contador_elevador_a++;
                break;
            case 'B':
                contador_elevador_b++;
                break;
            case 'C':
                contador_elevador_c++;
                break;
            default:
                printf("Elevador inválido. Use A, B ou C.\n");
                i--; 
                continue;
        }

        switch (periodo) {
            case 'M':
                contador_matutino++;
                break;
            case 'V':
                contador_vespertino++;
                break;
            case 'N':
                contador_noturno++;
                break;
            default:
                printf("Período inválido. Use M, V ou N.\n");
                i--; 
                continue;
        }
    }

  
    if (contador_elevador_a >= contador_elevador_b && contador_elevador_a >= contador_elevador_c) {
        elevador_mais_frequentado = 'A';
    } else if (contador_elevador_b >= contador_elevador_a && contador_elevador_b >= contador_elevador_c) {
        elevador_mais_frequentado = 'B';
    } else {
        elevador_mais_frequentado = 'C';
    }


    if (contador_matutino >= contador_vespertino && contador_matutino >= contador_noturno) {
        periodo_mais_usado = 'M';
        maior_fluxo = contador_matutino;
    } else if (contador_vespertino >= contador_matutino && contador_vespertino >= contador_noturno) {
        periodo_mais_usado = 'V';
        maior_fluxo = contador_vespertino;
    } else {
        periodo_mais_usado = 'N';
        maior_fluxo = contador_noturno;
    }

    
    int menor_fluxo = contador_matutino;
    if (contador_vespertino < menor_fluxo) {
        menor_fluxo = contador_vespertino;
    }
    if (contador_noturno < menor_fluxo) {
        menor_fluxo = contador_noturno;
    }
    float diferenca_percentual = ((float)(maior_fluxo - menor_fluxo) / maior_fluxo) * 100;

   
    int total_servicos_prestados = contador_matutino + contador_vespertino + contador_noturno;
    char elevador_media_utilizacao;
    if (contador_elevador_a >= contador_elevador_b && contador_elevador_a >= contador_elevador_c) {
        elevador_media_utilizacao = 'A';
    } else if (contador_elevador_b >= contador_elevador_a && contador_elevador_b >= contador_elevador_c) {
        elevador_media_utilizacao = 'B';
    } else {
        elevador_media_utilizacao = 'C';
    }
    float percentagem_media_utilizacao = ((float)(total_servicos_prestados - contador_elevador_media_utilizacao) / total_servicos_prestados) * 100;

    
    printf("Período mais usado de todos: %c (pertence ao elevador %c)\n", periodo_mais_usado, elevador_mais_frequentado);
    printf("Elevador mais frequentado: %c (no período %c com fluxo de %d)\n", elevador_mais_frequentado, periodo_mais_usado, maior_fluxo);
    printf("Diferença percentual entre o mais usado e o menos usado: %.2f%%\n", diferenca_percentual);
    printf("Percentagem sobre o total de serviços prestados do elevador de média utilização (%c): %.2f%%\n", elevador_media_utilizacao, percentagem_media_utilizacao);

    return 0;
}
