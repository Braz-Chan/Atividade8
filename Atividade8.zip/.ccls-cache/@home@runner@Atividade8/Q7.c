#include <stdio.h>
#include <ctype.h> 

int main() {
    int i, numero_homens = 0, numero_mulheres = 0;
    float altura_homens = 0, altura_mulheres = 0, altura_total = 0;
    float peso_homens = 0, peso_mulheres = 0, peso_total = 0;
    
    for (i = 1; i <= 10; i++) {
        char nome[50], sexo;
        float altura, peso;
        
        printf("Digite o nome da pessoa %d: ", i);
        scanf("%s", nome);
        
        printf("Digite o sexo da pessoa %d (M/F): ", i);
        scanf(" %c", &sexo); 
    
        printf("Digite a altura (em metros) da pessoa %d: ", i);
        scanf("%f", &altura);
        
        printf("Digite o peso (em kg) da pessoa %d: ", i);
        scanf("%f", &peso);
        
   
        sexo = tolower(sexo);
        
        if (sexo == 'm') {
            numero_homens++;
            altura_homens += altura;
            peso_homens += peso;
        } else if (sexo == 'f') {
            numero_mulheres++;
            altura_mulheres += altura;
            peso_mulheres += peso;
        } else {
            printf("Sexo inválido. Use M ou F.\n");
            i--; 
        }
        
        altura_total += altura;
        peso_total += peso;
    }
    
  
    float altura_media_homens = altura_homens / numero_homens;
    float altura_media_mulheres = altura_mulheres / numero_mulheres;
    float altura_media_total = altura_total / 10;
    
    float peso_media_homens = peso_homens / numero_homens;
    float peso_media_mulheres = peso_mulheres / numero_mulheres;
    float peso_media_total = peso_total / 10;
    
    printf("\nResultados:\n");
    printf("Número de homens: %d\n", numero_homens);
    printf("Número de mulheres: %d\n", numero_mulheres);
    printf("Altura média dos homens: %.2f metros\n", altura_media_homens);
    printf("Altura média das mulheres: %.2f metros\n", altura_media_mulheres);
    printf("Altura média do grupo: %.2f metros\n", altura_media_total);
    printf("Peso médio dos homens: %.2f kg\n", peso_media_homens);
    printf("Peso médio das mulheres: %.2f kg\n", peso_media_mulheres);
    printf("Peso médio do grupo: %.2f kg\n", peso_media_total);
    
    return 0;
}
