#include <stdio.h>

int main() {
    char resposta;
    
    do {
        int mes, ano, dias_no_mes;

        printf("Digite um mês (1-12): ");
        scanf("%d", &mes);

        if (mes < 1 || mes > 12) {
            printf("Mês inválido. Digite um valor entre 1 e 12.\n");
            continue;
        }

        printf("Digite um ano: ");
        scanf("%d", &ano);

        if (ano < 0) {
            printf("Ano inválido. Digite um valor positivo.\n");
            continue;
        }

        switch (mes) {
            case 4:
            case 6:
            case 9:
            case 11:
                dias_no_mes = 30;
                break;
            case 2:
                if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
                    dias_no_mes = 29; // Fevereiro em ano bissexto
                } else {
                    dias_no_mes = 28; // Fevereiro em ano não bissexto
                }
                break;
            default:
                dias_no_mes = 31;
        }

        printf("O mês %d do ano %d tem %d dias.\n", mes, ano, dias_no_mes);

        printf("VOCÊ DESEJA OUTRAS ENTRADAS (S/?)? ");
        scanf(" %c", &resposta);

    } while (resposta == 'S' || resposta == 's');

    return 0;
}
